
import SwiftUI
import CoreData

struct DetailView: View {
    @Environment(\.managedObjectContext) private var viewContext

    let detail:Restaurant
    @State private var isActive : Bool = false
    @State var showAlert = false
    @State var success = false

    init(detail: Restaurant) {
        self.detail = detail
    }
    var body: some View {
        NavigationLink(isActive: $isActive) {
            MapNavigationView()
                        } label: {
                            
                        }
        WebImageView(url: detail.image)
        Text(detail.name).font(.largeTitle)
            .font(Font.system(size: 28)).padding(20)
        Text(detail.address)
        Button("ADD TO FAVORITES") {
            let favorite = NSEntityDescription.insertNewObject(forEntityName: "Favorite",
                                                           into: self.viewContext) as! Favorite
            favorite.name = detail.name
            favorite.address = detail.address
            favorite.image = detail.image
            favorite.lat = detail.lat
            favorite.lng = detail.lng
        self.viewContext.insert(favorite)
            showAlert = true
            self.success = true
        }.buttonStyle(.borderedProminent).padding().alert(isPresented: $showAlert, content: {
            showAlert = false
            if(success){
                return Alert(title: Text("Success"), message: Text(""), dismissButton: .default(Text("OK")))
            }
            return Alert(title: Text("Error"), message: Text("Invalid Input!"), dismissButton: .default(Text("OK")))
        })
        
        Button("Start n Navigation") {
            isActive = true;
        }.buttonStyle(.borderedProminent).padding()
    }
}
