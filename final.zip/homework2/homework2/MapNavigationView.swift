
import SwiftUI
import MapKit
struct MapNavigationView: View {
    var body: some View {
        MyMapView(destination:CLLocationCoordinate2D(latitude:30,longitude: 120) )
    }
}

struct MapNavigationView_Previews: PreviewProvider {
    static var previews: some View {
        MapNavigationView()
    }
}
