
import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Favorite.name, ascending: true)],
        animation: .default)
    private var items: FetchedResults<Favorite>
    @State var isNavSearchPush:Bool = false
    
    @State private var isEditActive : Bool = false

    
    var body: some View {
        NavigationView {
            GeometryReader { geo in
                VStack(spacing: 30) {
                    NavigationLink(isActive: $isEditActive) {
                        EditProfileView()
                                    } label: {
                                        
                                    }
                    HStack{
                        Text("Resto")
                        Text("Finder")
                    }
                    Image("home").resizable().frame(width: 200,height: 200).aspectRatio(contentMode: .fit)
                    Text("Enjoy Beautiful Mealtime")
                    
                    NavigationLink(isActive: $isNavSearchPush) {
                        SearchView()
                    } label: {
                        Text("")
                    }.navigationTitle(Text(""))
                    Button{
                        isNavSearchPush = true
                    } label: {
                        Text("Find nearby restaurant")
                    }.buttonStyle(.borderedProminent).padding()
                    
                    Button("create profile") {
                        isEditActive = true;
                    }.buttonStyle(.borderedProminent).padding()
                    
                }.frame(width: geo.size.width,height: geo.size.height)
                
            }
            .edgesIgnoringSafeArea(.all)
        }.overlay(VStack{})
    }

}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
