

import SwiftUI
import PhotosUI
import CoreData

struct EditProfileView: View {
    @Environment(\.managedObjectContext) private var viewContext

    @Environment(\.presentationMode) var presentationMode
    @State private var selected: PhotosPickerItem?
    @State private var picture: UIImage?
    
    @State private var avatarItem: PhotosPickerItem?

    @State var username = ""
    @State var age = ""
    @State var favorite = ""
    @State var favorite2 = ""
    @State var showAlert = false
    @State var success = false
    
    func queryData()
    {

        let fetchRequest = NSFetchRequest<User>(entityName:"User")
        fetchRequest.fetchLimit = 10
        fetchRequest.fetchOffset = 0
       
       
        do {
            let fetchedObjects = try PersistenceController.shared.container.viewContext.fetch(fetchRequest)
            print("fetchedObjects=\(fetchedObjects.count)")
            for info in fetchedObjects{
                username = info.username ?? "";
                age = "\(info.age)";
                favorite = info.favorite ?? "";
                favorite2 = info.favorite2 ?? "";
            }
            print("nihao")
        }
        catch {
            fatalError("：\(error)")
        }
    }
    
    var body: some View {
        VStack{
            HStack{
                Button("Back") {
                    presentationMode.wrappedValue.dismiss() 
                }.background(Color.white).buttonStyle(.borderedProminent).padding()
                Text("Add Profile")
                Button("Save") {
                    let user = NSEntityDescription.insertNewObject(forEntityName: "User",
                                                                   into: self.viewContext) as! User
                    user.username = username
                    if(age != ""){
                        user.age = Int16((age as NSString).intValue)
                    }
                    
                    user.favorite = favorite
                    user.favorite2 = favorite2
                    self.viewContext.insert(user)
                    showAlert = true
                    self.success = true
                }.background(Color.white).buttonStyle(.borderedProminent).padding().alert(isPresented: $showAlert, content: {
                    showAlert = false
                    if(success){
                        return Alert(title: Text("Success"), message: Text(""), dismissButton: .default(Text("OK")))
                    }
                    return Alert(title: Text("Error"), message: Text("Invalid Input!"), dismissButton: .default(Text("OK")))
                })
            }
            HStack{
                Text("Username:")
                TextField(text: $username,
                          prompt: Text("Username")) {}.padding()
            }
            .padding()
            
            HStack{
                Text("Age:")
                TextField(text: $age,
                          prompt: Text("Age")) {}.padding().keyboardType(.numberPad)
            }
            .padding()
            
            HStack{
                Text("Favorite:")
                TextField(text: $favorite,
                          prompt: Text("Favorite")) {}.padding()
            }
            .padding()
            
            HStack{
                Text("Favorite:")
                TextField(text: $favorite2,
                          prompt: Text("Favorite")) {}.padding()
            }
            .padding()
            
            
            PhotosPicker(selection: $selected, matching: .images, photoLibrary: .shared()) {
                Text("Select profile image")
                    .padding()
                    .buttonStyle(.borderedProminent)
                
                
                
            }
            
            
        }.onAppear{
            queryData()
        }
    }
}

struct EditProfileView_Previews: PreviewProvider {
    static var previews: some View {
        EditProfileView()
    }
}
