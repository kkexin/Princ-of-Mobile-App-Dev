

import SwiftUI
import MapKit

struct SearchView: View {
    @State private var list:Array<Restaurant> = []
    @State private var isProfileActive : Bool = false
    @State private var isDetailActive : Bool = false
    @State private var detail:Restaurant = Restaurant()
    @Environment(\.presentationMode) var presentationMode
    
    func query() {
        var network = HttpNetwork()
        network.httpGet(from: "https://www.xiaowanwu.cn/shoppingapi/restaurant/query", complete: { (response:Array<Restaurant>) in
            list = response
        }, onerror: {err in
            
        })
        
    }
   
    init(){
        
    }
    var body: some View {
        NavigationView {
            
            VStack{
                HStack{
                    Image("before").resizable().frame(width: 30,height: 30).aspectRatio(contentMode: .fit).onTapGesture {
                        presentationMode.wrappedValue.dismiss()
                    }
                   Text("22 45th, Clinton Hill")
                    NavigationLink(isActive: $isProfileActive) {
                        ProfileView()
                                    } label: {
                                        
                                    }
                    Image("next").resizable().frame(width: 30,height: 30).aspectRatio(contentMode: .fit).onTapGesture(count: 1) {
                        isProfileActive = true;
                   }
               }
                NavigationLink(isActive: $isDetailActive) {
                    DetailView(detail: detail)
                                } label: {
                                    
                                }
                MyMapView(destination:CLLocationCoordinate2D(latitude:30,longitude: 120) ).frame(width: 300,height: 300)
                VStack{
                    Text("sorted restaurants by")
                    Table(list){
                        TableColumn("joined at") { restaurant in
                            HStack{
                                VStack {
                                    Text("\(restaurant.index)").foregroundColor(.white).padding(15)
                                }
                                .background(Color.black).padding(10)
                                
                                VStack(alignment: .leading){
                                    Text(restaurant.name)
                                    Text(restaurant.address)
                                }
                            }.onTapGesture {
                                detail = restaurant;
                                isDetailActive = true;
                            }
                        }
                    }
                    
                }
            }
        }
            .padding().navigationBarHidden(true).onAppear {
                query();
            }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchView()
    }
    
    
}
