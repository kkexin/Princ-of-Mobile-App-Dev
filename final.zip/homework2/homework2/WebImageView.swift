
import SwiftUI


struct WebImageView:View  {
    var url:String = ""
    @State private var remoteImage : UIImage? = nil
    let placeholderOne = UIImage(named: "picture")
    
    init(url: String = "") {
        self.url = url;
        print("remoteImage=="+url)
    }
    var body: some View {
        
        Image(uiImage: self.remoteImage ?? placeholderOne!).resizable()
            .onAppear(perform: fetchRemoteImage).aspectRatio(contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 10))
    }
    
    func fetchRemoteImage()
    {
        guard let url = URL(string: url) else { return }
        URLSession.shared.dataTask(with: url){ (data, response, error) in
            if let image = UIImage(data: data!){
                self.remoteImage = image
            }
            else{
                print(error ?? "")
            }
        }.resume()
    }
}

