//
//  Network.swift
//  homework2
//
//  Created by bd on 2023/11/20.
//

import SwiftUI

struct Network: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Network_Previews: PreviewProvider {
    static var previews: some View {
        Network()
    }
}
