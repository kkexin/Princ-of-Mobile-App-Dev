//
//  Profile.swift
//  homework2
//
//  Created by bd on 2023/11/20.
//

import SwiftUI

struct Profile: View {
    var body: some View {
        VStack{
            
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
