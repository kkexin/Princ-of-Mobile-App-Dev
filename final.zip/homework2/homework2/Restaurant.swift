
import Foundation

class Restaurant : Identifiable,Codable {
    var image:String = ""
    var name:String = ""
    var address:String = ""
    var lat:Double = 0
    var lng:Double = 0
    var index:Int16 = 0;
    init(name: String = "", address: String = "", lat: Double = 0, lng: Double = 0,image:String="") {
        self.name = name
        self.address = address
        self.lat = lat
        self.lng = lng
        self.image = image
    }
}
