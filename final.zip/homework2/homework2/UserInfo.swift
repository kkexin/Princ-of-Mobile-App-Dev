
import Foundation

class UserInfo : Identifiable,Codable {
    var username:String = ""
    var age:Int16 = 0
    var favorite:String = ""
    var favorite2:String = ""
    init(username: String = "", age: Int16 = 0, favorite:String = "",favorite2:String = "") {
        self.username = username
        self.age = age
        self.favorite = favorite
        self.favorite2 = favorite2
    }
}
