
import SwiftUI
import CoreData

struct ProfileView: View {
    @State var list:Array<Restaurant> = []
    @State private var isEditActive : Bool = false
    @Environment(\.managedObjectContext) private var viewContext

    func queryData()
    {

        let fetchRequest = NSFetchRequest<Favorite>(entityName:"Favorite")
        fetchRequest.fetchLimit = 10
        fetchRequest.fetchOffset = 0
       
        list = []
        do {
            let fetchedObjects = try PersistenceController.shared.container.viewContext.fetch(fetchRequest)
            print("fetchedObjects=\(fetchedObjects.count)")
            for info in fetchedObjects{
              
                list.append(Restaurant(name: info.name ?? "", address: info.address ?? "", lat:info.lat ?? 0, lng:info.lng ?? 0, image:info.image ?? ""))
                
            }
            
           
            print("nihao")
        }
        catch {
            fatalError("：\(error)")
        }
    }
   

    var body: some View {
        VStack{
            NavigationLink(isActive: $isEditActive) {
                EditProfileView()
                            } label: {
                                
                            }
            HStack{
                Image("headimg").resizable().frame(width: 80,height: 80).aspectRatio(contentMode: .fit)
                VStack{
                    Text("Jane Joe")
                    Text("22 Years Old")
                    Button("Edit profile") {
                        isEditActive = true;
                    }.buttonStyle(.borderedProminent).padding(20)
                }
            }
            HStack{
                VStack{
                    Text("\(list.count) favorite").foregroundColor(Color.white).padding(10)
                }.background(Color.black).padding(10)
                VStack{
                    Text("12 visted").foregroundColor(Color.white).padding(10)
                }.background(Color.black)
            }
            Text("My favorite")
            Table(list){
                TableColumn("joined at") { restaurant in
                    HStack{
                        WebImageView(url: restaurant.image).frame(width: 80,height: 100)
                        VStack(alignment: .leading){
                            Text(restaurant.name)
                            Text(restaurant.address)
                        }
                    }
                }
            }
        }.onAppear {
            queryData();
        }
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
