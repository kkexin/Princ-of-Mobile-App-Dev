import SwiftUI

struct RestaurantDetail: View {
    var body: some View {
        VStack {
            Image("restaurant_image") 
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: 200)
            
            Text("Restaurant Name")
                .font(.title)
                .padding()
            
            Text("Restaurant Address")
                .font(.italic())
                .padding()
            
            Spacer()
            
            HStack {
                Button(action: {
                }) {
                    Text("back")
                }
                .padding()
                
                Button(action: {
                   
                }) {
                    Text("Start Navigation")
                }
                .padding()
            }
        }
        .navigationBarTitle("Restaurant Detail", displayMode: .inline)
    }
}

@main
struct restofinderApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                RestaurantDetail()
            }
        }
    }
}
